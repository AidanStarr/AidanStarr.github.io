function h=misplot(varargin)
%MISPLOT plots Marine Isotope Stage boundaries onto the current axis (presumably a paleoclimate time series plot; time must be on the x-axis. The MIS names and boundaries are as defined by http://lorraine-lisiecki.com/LR04_MISboundaries.txt
%
%%Syntax
%
%misplot('MIS boundary name','MIS boundary name',...)
%e.g. for MIS 7: misplot('7')
%e.g. for MIS NS5 and MIS T1: misplot('NS5','T1')
%optional output h gives the handle of patches plotted
if nargin == 0
    if exist('MISboundaries.txt')==0
        urlwrite('https://raw.githubusercontent.com/AidanStarr/Paleoplotting/master/MISboundaries.txt','filename');
        y=fopen('filename');
    else
        y=fopen('MISboundaries.txt');
    end
   
    y=textscan(y,'%s');
    y=y{1};
    for i = [2:4:400]
         ax=gca;
         p1 = str2double(y{i});
         p2 = str2double(y{i+2});
         h(i)=patch([p1 p1, p2 p2], [min(ax.YLim) max(ax.YLim) max(ax.YLim) min(ax.YLim)], [0.3529    0.4902    0.6039],'edgecolor','none','facealpha',0.2);
        hold on
        text(mean([p1 p2]),min(ax.YLim),y{i+1},'Rotation',60)
    end
else

%set loop for varargin length
for k=1:2:nargin
a1=varargin{k};

%open and setup reference text file
if exist('MISboundaries.txt')==0
   urlwrite('https://raw.githubusercontent.com/AidanStarr/Paleoplotting/master/MISboundaries.txt','filename');
    y=fopen('filename');
else
    y=fopen('MISboundaries.txt');
end

y=textscan(y,'%s');
y=y{1};
pos=find(strcmpi(y,a1));

%setup MIS 1
if pos==1
p1=0;
p2=str2double(y{pos+1});
ax=gca;
h(k)=patch([p1 p1,p2 p2], [min(ax.YLim) max(ax.YLim) max(ax.YLim) min(ax.YLim)], [0.3529    0.4902    0.6039],'edgecolor','none','facealpha',0.2);
else
    p1=str2double(y{pos-1});
p2=str2double(y{pos+1});
ax=gca;
h(k)=patch([p1 p1,p2 p2], [min(ax.YLim) max(ax.YLim) max(ax.YLim) min(ax.YLim)], [0.3529    0.4902    0.6039],'edgecolor','none','facealpha',0.2);
hold on
text(mean([p1 p2]),min(ax.YLim),varargin{k},'Rotation',60)
end

end
for k=2:2:nargin
a1=varargin{k};

y=fopen('MISboundaries.txt');
y=textscan(y,'%s');
y=y{1};
pos=find(strcmpi(y,a1));


if pos==1
p1=0;
p2=str2double(y{pos+1});
ax=gca;
h(k)=patch([p1 p1,p2 p2], [min(ax.YLim) max(ax.YLim) max(ax.YLim) min(ax.YLim)], [.9765    0.4510    0.0235],'edgecolor','none','facealpha',0.2);
else
    p1=str2double(y{pos-1});
p2=str2double(y{pos+1});
ax=gca;
h(k)=patch([p1 p1,p2 p2], [min(ax.YLim) max(ax.YLim) max(ax.YLim) min(ax.YLim)], [.9765    0.4510    0.0235],'edgecolor','none','facealpha',0.2);
hold on
text(mean([p1 p2]),min(ax.YLim),varargin{k},'Rotation',60)
end
end
end
hold off
end


